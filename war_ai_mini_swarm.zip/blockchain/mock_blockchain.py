def log_threat(threat_name, severity=1):
    print(f"[Blockchain] Logging threat '{threat_name}' with severity {severity} (mock).")
    return True
